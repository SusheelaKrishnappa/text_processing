import text_processing.WordFrequencyAnalyzer as wfa
import pytest


def test_calculate_highest_frequency():
    word = "the sun shines over the lake"
    obj = wfa.WordFrequencyAnalyzer(word)
    res = obj.calculate_highest_frequency()
    print("Highest frequency", res)
    assert res == 2


def test_calculate_frequency_for_word():
    word = "the sun shines over the lake"
    text = "the"
    obj = wfa.WordFrequencyAnalyzer(word, text)
    res = obj.calculate_frequency_for_word()
    assert res == 2


def test_calculate_most_frequent_n_words():
    word = "the sun shines over the lake"
    n = 3
    obj = wfa.WordFrequencyAnalyzer()
    res = obj.calculate_most_frequent_n_words(text=word, n=n)
    for items in res:
        print("\n", items.word, items.frequency)



