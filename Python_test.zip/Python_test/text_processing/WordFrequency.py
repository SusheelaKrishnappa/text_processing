
class WordFrequency:
    def __init__(self,word,frequency):
        self.word = word
        self.frequency = frequency
