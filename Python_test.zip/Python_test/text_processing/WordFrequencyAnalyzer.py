from collections import Counter
import text_processing.WordFrequency as wf
import re


class WordFrequencyAnalyzer:
    def __init__(self, word=None, text=None, n=None):
        self.word = word
        self.text = text
        self.n = n

    # Method returns highest frequency in the text
    def calculate_highest_frequency(self):
        word_list = self.word.split(" ")
        counter = Counter(word_list)
        return counter.most_common()[0][1]

    # Method returns frequency for specified word
    def calculate_frequency_for_word(self):
        count = 0
        word_list = self.word.split(" ")
        for wrd in word_list:
            if re.match(wrd, self.text, re.IGNORECASE):
                count += 1
        return count

    # Method calculates most frequent n words
    def calculate_most_frequent_n_words(self):
        word_list = self.word.split(" ")
        counter = Counter(word_list)
        result = counter.most_common()
        # len of result to use for remove n results
        cnt = len(result) - 1
        # List of WordFrequency,add the first result without sorting
        list_of_wf = [wf.WordFrequency(word=result[0][0], frequency=result[0][1])]
        # Sorted the op based on alphabetical order excluding first result
        sor = sorted(result)
        i = 1
        for k in sor:
            if cnt > self.n - 1:
                list_of_wf.append(wf.WordFrequency(k[0], k[1]))
                cnt -= 1
        return list_of_wf
