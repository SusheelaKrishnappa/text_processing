# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import text_processing.WordFrequencyAnalyzer as wfa


# Text processing method
def text_processing(word, text):
    obj = wfa.WordFrequencyAnalyzer(word, text, 3)
    print("highest frequency", obj.calculate_highest_frequency())
    print("freq for word - the", obj.calculate_frequency_for_word())
    res = obj.calculate_most_frequent_n_words()
    for items in res:
        print(items.word, items.frequency)


# Main
if __name__ == '__main__':
    word = input("Enter the text for processing")
    text = input("Enter text for finding its frequency")
    text_processing(word, text)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
